# Modelo preenchido — classe `ifftese.cls`

Rascunho didático de um TCC **completo e preenchido** (dados fictícios), usando
`ifftese.cls` + `macros.sty` + `metadados.sty`. O objetivo não é ser um TCC de
verdade — é te mostrar, com sintaxe real e funcionando, como cada comando da
classe é usado na prática, comentado linha a linha nos próprios arquivos `.tex`.

Leia estes três arquivos junto com este modelo, nesta ordem:

1. **Aula 06 — Classe `ifftese.cls`** — o que cada flag/comando faz por dentro.
2. **Aula 07 — Pacote `macros.sty`** — as macros de conteúdo (capa, figuras, ambientes de teorema).
3. **Aula 08 — Arquivo `metadados.sty`** — este arquivo, explicado campo a campo.

(as três estão em `pt-br/resource/latex/` no site.)

## Estrutura do pacote

```
metadados.sty                    ← comece por aqui: troque os dados fictícios pelos seus
TCC-Modelo.tex                   ← arquivo principal (ordem de montagem do documento)
01-introducao.tex                ← seções, siglas/símbolos, \index
02-fundamentacao-teorica.tex     ← ambientes definicao/exemplo/observacao, glossário
03-metodologia-e-resultados.tex  ← figuras, tabelas, quadros, gráficos, algoritmo
04-consideracoes-finais.tex      ← capítulo de fechamento
apendices.tex                    ← \capituloapendice + problema/desafio/exercício com resposta cruzada
anexos.tex                       ← \capituloanexo
referencias.bib                  ← bibliografia (abntex2cite/BibTeX)
img/exemplo-arquitetura.png      ← imagem placeholder — troque pelas suas figuras reais
ifftese.cls, macros.sty          ← a classe e o pacote de macros (não precisam de edição)
```

## Como compilar

```
pdflatex TCC-Modelo
bibtex TCC-Modelo      # ou biber, se preferir
pdflatex TCC-Modelo
pdflatex TCC-Modelo    # a 2ª/3ª passada são necessárias: sumário, listas de
                       # figuras/siglas/símbolos e o glossário dependem de
                       # dados gravados no .aux na passada anterior
```

Funciona em qualquer distribuição LaTeX moderna (TeX Live, MacTeX, MiKTeX) ou
no Overleaf — basta subir os arquivos deste pacote como um projeto novo e
compilar `TCC-Modelo.tex` como arquivo principal.

## Nota honesta

Este pacote foi montado e revisado por leitura cuidadosa do código-fonte real
da classe (não há um compilador LaTeX disponível no ambiente onde foi
gerado), então **teste localmente antes de confiar nele para o seu próprio
trabalho** — em especial `\inserirfigura` (Aula 07, nota de rodapé sobre um
espaço estranho em `\figuracaminho/ #2` dentro de `macros.sty`, que pode
precisar de ajuste dependendo da sua distribuição LaTeX).
